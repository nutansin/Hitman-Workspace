---
title: "mg_send_mqtt_handshake_opt()"
decl_name: "mg_send_mqtt_handshake_opt"
symbol_kind: "func"
signature: |
  void mg_send_mqtt_handshake_opt(struct mg_connection *nc, const char *client_id,
                                  struct mg_send_mqtt_handshake_opts);
---

Sends an MQTT handshake with optional parameters. 

