/*
 * Copyright (c) 2014-2016 Cesanta Software Limited
 * All rights reserved
 */

/* clang-format off */

void bleconfig_init(void);
void bleconfig_poll(void);

