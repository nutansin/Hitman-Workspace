/*
 * Copyright (c) 2014-2016 Cesanta Software Limited
 * All rights reserved
 */

void bleconfig_init(void);
void bleconfig_poll(void);
