Mongoose Web Server example without an RTOS
===========================================

This project sets up a simple Web server using the Mongoose Web Server and
Networking library.

This project depends on lpc_chip_40xx and lpc_board_ea_devkit_4088 (for
drivers) and the webserver example project (for LWIP).
